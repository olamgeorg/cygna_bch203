create table if not exists profiles(id uuid primary key references auth.users(id) on delete cascade,full_name text,email text,role text default 'student',app_name text,created_at timestamptz default now());
create table if not exists results(id uuid primary key default gen_random_uuid(),user_id uuid references auth.users(id) on delete cascade,full_name text,email text,app_name text,topics text,mode text,score int,total_questions int,percentage int,grade text,pass_fail text,time_used text,created_at timestamptz default now());
alter table profiles enable row level security;alter table results enable row level security;
create or replace function is_admin() returns boolean language sql stable as $$select lower(coalesce(auth.jwt()->>'email',''))='olamgeorg9@gmail.com'$$;
create policy "p_sel" on profiles for select using(auth.uid()=id or is_admin());
create policy "p_ins" on profiles for insert with check(auth.uid()=id);
create policy "p_upd" on profiles for update using(auth.uid()=id or is_admin());
create policy "p_del" on profiles for delete using(is_admin());
create policy "r_sel" on results for select using(auth.uid()=user_id or is_admin());
create policy "r_ins" on results for insert with check(auth.uid()=user_id);
create policy "r_del" on results for delete using(is_admin());
create or replace function handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin insert into profiles(id,full_name,email,role,app_name) values(new.id,coalesce(new.raw_user_meta_data->>'full_name',new.email),new.email,'student',coalesce(new.raw_user_meta_data->>'app_name','cygna_bch203')) on conflict do nothing;return new;end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();
